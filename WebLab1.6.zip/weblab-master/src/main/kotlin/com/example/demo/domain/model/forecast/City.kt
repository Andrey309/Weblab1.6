package com.example.demo.domain.model.forecast

data class City(val name: String)
