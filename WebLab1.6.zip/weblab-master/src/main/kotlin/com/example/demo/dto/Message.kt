package com.example.demo.dto

data class Message(val message: String)
