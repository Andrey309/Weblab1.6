package com.example.demo.domain.model.weather

data class Weather(
    val main: String,
    val description: String
)
