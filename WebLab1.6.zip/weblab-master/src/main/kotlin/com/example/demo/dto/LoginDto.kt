package com.example.demo.dto

data class LoginDto(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val city: String = ""
)
