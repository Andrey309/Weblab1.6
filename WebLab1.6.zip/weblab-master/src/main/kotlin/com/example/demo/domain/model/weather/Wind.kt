package com.example.demo.domain.model.weather

data class Wind(
    val speed: Double,
    val deg: Int
)
